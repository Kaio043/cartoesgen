require("dotenv").config();
const { Client, GatewayIntentBits } = require("discord.js");

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent]
});

const prefix = process.env.PREFIX;
const token = process.env.TOKEN;

client.once("ready", () => {
  console.log(`🤖 Bot está online como ${client.user.tag}`);
});

client.login(token);
