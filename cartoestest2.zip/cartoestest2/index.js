const { Client, GatewayIntentBits } = require('discord.js');
require('dotenv').config();

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

// Função para gerar um número de cartão aleatório
function gerarNumeroCartao() {
    return Array.from({ length: 16 }, () => Math.floor(Math.random() * 10)).join('');
}

// Função para gerar CVV aleatório
function gerarCVV() {
    return Math.floor(100 + Math.random() * 900).toString();
}

// Função para gerar data de validade
function gerarDataValidade() {
    const mes = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
    const ano = String(Math.floor(Math.random() * 6) + 25); // Expira entre 2025 e 2030
    return `${mes}/${ano}`;
}

// Função para escolher uma bandeira aleatória
function gerarBandeira() {
    const bandeiras = ['Visa', 'MasterCard', 'American Express', 'Discover', 'Elo'];
    return bandeiras[Math.floor(Math.random() * bandeiras.length)];
}

// Função para escolher um país aleatório
function gerarPais() {
    const paises = ['Brasil', 'EUA', 'Canadá', 'Reino Unido', 'Alemanha', 'Austrália'];
    return paises[Math.floor(Math.random() * paises.length)];
}

client.on('messageCreate', async message => {
    if (message.content.toLowerCase() === '!gerarcartao') {
        const cartao = {
            numero: gerarNumeroCartao(),
            cvv: gerarCVV(),
            validade: gerarDataValidade(),
            bandeira: gerarBandeira(),
            pais: gerarPais()
        };
        
        message.reply(`💳 Cartão Gerado:\nNúmero: ${cartao.numero}\nCVV: ${cartao.cvv}\nValidade: ${cartao.validade}\nBandeira: ${cartao.bandeira}\nPaís: ${cartao.pais}`);
    }
});

client.login(process.env.TOKEN_ENV);